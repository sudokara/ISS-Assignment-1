# Shrikara A
# 2021101058

https://github.com/sudokara/ISS-Assignment-1
Please see comments in code for explanations

## Q1
The outputs are printed onto terminal.They are separated by a line of dashes(-)
 
## Q2
The output is sent to file `speech.txt`

## Q3
The outputs are printed to terminal. For part e, `word` `word,` and `word.` are considered equivalent, ie commas and fullstops do not count towards a word.

## Q4
Bubblesort the given array

## Q5
Print the outputs to the terminal